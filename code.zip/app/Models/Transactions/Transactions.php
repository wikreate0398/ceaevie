<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 25.05.2019
 * Time: 22:16
 */

namespace App\Models\Transactions;

use Illuminate\Database\Eloquent\Model;

class Transactions extends Model
{
    public $timestamps = true;

    protected $table = 'transactions';

    protected $fillable = [
        'id_user',
        'transaction_type',
        'type',
        'price',
        'product_code',
        'ballance'
    ];

    public function type_data()
    {
        return $this->hasOne('App\Models\Transactions\TransactionTypes', 'var', 'transaction_type');
    }
}