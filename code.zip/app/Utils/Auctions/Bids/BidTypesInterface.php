<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 12.03.2019
 * Time: 18:06
 */

namespace App\Utils\Auctions\Bids;


interface BidTypesInterface
{
    public function get();
}