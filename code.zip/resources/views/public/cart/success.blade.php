@extends('layouts.public')

@section('content')
    <section class="checkout">
        <div class="container">
            <a href="#" class="banner" style="background-image: url('/img/licitatii_specifice/banner.png');"></a>
            <div class="alert alert-success">
                Заказ успешно добавлен
            </div>
        </div>
    </section>
@stop

