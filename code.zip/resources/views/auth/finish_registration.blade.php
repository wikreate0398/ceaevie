@extends('layouts.public')

@section('content')
    <section class="text_container">
        <div class="container">
            <div class="row">
                {{ $message }}
            </div>
        </div>
    </section>
@stop

