@extends('layouts.public')

@section('content')
        <section class="oferte_plasate">
        <div class="container">

            @if($bids->count())
                <div class="tab-content">
                    <div class="table-head">
                        <div class="item" data-number="1">Data <br>plasarii</div>
                        <div class="item" data-number="2"><span class="darken">Denumirea produsului</span></div>
                        <div class="item" data-number="3">COD Licitatie</div>
                        <div class="item" data-number="4"><span class="darken">Oferta de pret inregistrata</span></div>
                        <div class="item" data-number="5">Tip inregisrare</div>
                    </div>
                    <div class="table-body">
                        
                        @foreach($bids as $bid)  
                            <div class="result_item">
                                <div class="item" data-number="1">
                                    {{ $bid->created_at->format('d.m.Y') }} <br> {{ $bid->created_at->format('H:i') }}
                                </div>
                                <div class="item" data-number="2">
                                    <span class="title">{{ $bid->auction["name_$lang"] }}</span>
                                    <p>{{ $bid->auction["name2_$lang"] }}</p>
                                </div>
                                <div class="item" data-number="3">{{ $bid->auction->code }}</div>
                                <div class="item" data-number="4">
                                    <span class="price">{{ $bid->price }} LEI</span>
                                </div>
                                <div class="item" data-number="5">Electronic</div>
                            </div>
                        @endforeach 

                    </div>
                </div>

                {{ $bids->links() }}  

            @else
                <div class="alert _2">
                    <p>Nu sunt oferte</p>
                </div>
            @endif

        </div>
    </section>
@stop