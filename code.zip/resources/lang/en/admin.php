<?php

return [
	'save'        => 'Data saved successfully',
	'ajax_true'   => 'Changes saved successfully',
	'delete_true' => 'Record successfully deleted',
	'update_pass' => 'Password successfully changed',
	'added_user'  => 'User successfully added',
    'error_login' => 'Authorisation Error',
    'welcome'     => 'Welcome!',
    'req_fields'  => 'Fill in all required fields!',
    'already_exits' => 'A user with this login already exists.',
];